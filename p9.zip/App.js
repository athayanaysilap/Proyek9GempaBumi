import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  ActivityIndicator,
  SafeAreaView,
  RefreshControl,
  TouchableOpacity,
  StatusBar,
  Platform,
  TextInput,
  Modal,
  Image,
} from 'react-native';

// Data cadangan offline jika diperlukan
const DEMO_DATA = {
  Tanggal: "06 Nov 2026",
  Jam: "03:20:00 WIB",
  DateTime: "2026-11-05T20:20:00+00:00",
  Coordinates: "-1.14,120.15",
  Lintang: "1.14 LS",
  Bujur: "120.15 BT",
  Magnitude: "4.8",
  Kedalaman: "10 km",
  Wilayah: "Pusat gempa berada di darat 40 km timur laut Sigi",
  Potensi: "Gempa ini dirasakan untuk diteruskan pada masyarakat",
  Dirasakan: "III Sigi, II Palu",
  Shakemap: "20261104145634.mmi.jpg"
};

export default function App() {
  const [ipAddress, setIpAddress] = useState('192.168.1.5');
  const [port, setPort] = useState('3000');
  const [tempIp, setTempIp] = useState('192.168.1.5');
  const [showConfigModal, setShowConfigModal] = useState(false);

  const [dataSource, setDataSource] = useState('backend');
  const [dataGempa, setDataGempa] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);

  const fetchData = useCallback(async (source = dataSource, currentIp = ipAddress, currentPort = port) => {
    if (source === 'demo') {
      setDataGempa([DEMO_DATA]);
      setDataSource('demo');
      setErrorMessage(null);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    let targetUrl = '';
    if (source === 'backend') {
      targetUrl = `http://${currentIp}:${currentPort}/api/gempa`;
    } else {
      targetUrl = 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json';
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);

    try {
      setErrorMessage(null);
      const response = await fetch(targetUrl, { signal: controller.signal });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const json = await response.json();
      const gempa = json?.Infogempa?.gempa;

      if (Array.isArray(gempa)) {
        setDataGempa(gempa);
      } else if (gempa && typeof gempa === 'object') {
        setDataGempa([gempa]);
      } else {
        setDataGempa([]);
      }
      setDataSource(source);
    } catch (err) {
      console.warn('Gagal fetch dari:', targetUrl, err.message);
      if (source === 'backend') {
        setErrorMessage(
          `Tidak dapat terhubung ke Backend (${targetUrl}).\n\n` +
          `Penyebab:\n` +
          `1. Server backend belum dijalankan (jalankan 'node app.js' di folder backend).\n` +
          `2. Port 3000 diblokir Windows Firewall.\n` +
          `3. IP laptop (${currentIp}) telah berubah atau HP tidak di Wi-Fi yang sama.`
        );
      } else {
        setErrorMessage(`Gagal mengambil data BMKG online (${err.message}).`);
      }
    } finally {
      clearTimeout(timeoutId);
      setLoading(false);
      setRefreshing(false);
    }
  }, [dataSource, ipAddress, port]);

  // Muat data saat awal + Auto-refresh setiap 10 detik
  useEffect(() => {
    fetchData('backend', ipAddress, port);

    const intervalId = setInterval(() => {
      fetchData(dataSource, ipAddress, port);
    }, 10000); // 10000ms = 10 detik

    return () => clearInterval(intervalId);
  }, [dataSource, ipAddress, port, fetchData]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchData(dataSource, ipAddress, port);
  };

  const handleSaveIp = () => {
    setIpAddress(tempIp.trim());
    setShowConfigModal(false);
    setLoading(true);
    fetchData('backend', tempIp.trim(), port);
  };

  const getMagColor = (mag) => {
    const val = parseFloat(mag);
    if (isNaN(val)) return '#d9534f';
    if (val >= 6.0) return '#c9302c';
    if (val >= 5.0) return '#d9534f';
    if (val >= 4.0) return '#ec971f';
    return '#31b0d5';
  };

  if (loading && !refreshing) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#d9534f" />
        <Text style={styles.loadingText}>Menghubungi Server...</Text>
        <Text style={styles.loadingSubtext}>
          {dataSource === 'backend' ? `http://${ipAddress}:${port}/api/gempa` : 'BMKG Server'}
        </Text>
      </View>
    );
  }

  if (errorMessage && dataGempa.length === 0) {
    return (
      <SafeAreaView style={styles.centerContainer}>
        <Text style={styles.errorIcon}>📡</Text>
        <Text style={styles.errorTitle}>Koneksi Terputus</Text>
        <Text style={styles.errorText}>{errorMessage}</Text>

        <View style={styles.actionButtonContainer}>
          <TouchableOpacity
            style={[styles.primaryButton, { backgroundColor: '#d9534f' }]}
            onPress={() => { setLoading(true); fetchData('backend', ipAddress, port); }}
          >
            <Text style={styles.buttonText}>🔄 Coba Hubungkan Ulang</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.primaryButton, { backgroundColor: '#0275d8' }]}
            onPress={() => { setLoading(true); fetchData('bmkg'); }}
          >
            <Text style={styles.buttonText}>🌐 Gunakan BMKG Online (Direct)</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.primaryButton, { backgroundColor: '#5cb85c' }]}
            onPress={() => fetchData('demo')}
          >
            <Text style={styles.buttonText}>💾 Gunakan Data Demo (Offline)</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.primaryButton, { backgroundColor: '#6c757d' }]}
            onPress={() => setShowConfigModal(true)}
          >
            <Text style={styles.buttonText}>⚙️ Atur Ulang IP Laptop</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const renderItem = ({ item }) => {
    const magBg = getMagColor(item?.Magnitude);
    const shakemapUrl = item?.Shakemap
      ? `https://data.bmkg.go.id/DataMKG/TEWS/${item.Shakemap}`
      : null;

    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={[styles.magBadge, { backgroundColor: magBg }]}>
            <Text style={styles.magLabel}>MAGNITUDO</Text>
            <Text style={styles.magValue}>{item?.Magnitude || '-'}</Text>
          </View>
          <View style={styles.timeInfo}>
            <Text style={styles.dateText}>📅 {item?.Tanggal || '-'}</Text>
            <Text style={styles.timeText}>🕒 {item?.Jam || '-'}</Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>📍 Pusat Gempa:</Text>
          <Text style={styles.detailValue}>{item?.Wilayah || '-'}</Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>📏 Kedalaman:</Text>
          <Text style={styles.detailValue}>{item?.Kedalaman || '-'}</Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>🌐 Koordinat:</Text>
          <Text style={styles.detailValue}>
            {item?.Lintang || '-'} , {item?.Bujur || '-'}
          </Text>
        </View>

        {item?.Dirasakan ? (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>👥 Dirasakan di:</Text>
            <Text style={styles.detailValue}>{item.Dirasakan}</Text>
          </View>
        ) : null}

        {item?.Potensi ? (
          <View style={styles.potensiBox}>
            <Text style={styles.potensiText}>⚠️ {item.Potensi}</Text>
          </View>
        ) : null}

        {shakemapUrl ? (
          <View style={styles.shakemapBox}>
            <Text style={styles.shakemapTitle}>🗺️ Peta Guncangan (Shakemap):</Text>
            <Image
              source={{ uri: shakemapUrl }}
              style={styles.shakemapImage}
              resizeMode="contain"
            />
          </View>
        ) : null}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f4f6f9" />

      <View style={styles.header}>
        <Text style={styles.headerTitle}>Info Gempa Bumi Terkini</Text>
        <Text style={styles.headerSubtitle}>Modul Praktikum React Native</Text>

        <TouchableOpacity
          style={styles.sourceBadge}
          onPress={() => setShowConfigModal(true)}
        >
          <Text style={styles.sourceBadgeText}>
            {dataSource === 'backend' && `🟢 Backend: ${ipAddress}:${port}`}
            {dataSource === 'bmkg' && `🌐 BMKG Online Langsung`}
            {dataSource === 'demo' && `💾 Mode Demo Offline`}
            {'  (⚙️ Ganti)'}
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={dataGempa}
        keyExtractor={(item, index) => item?.DateTime || index.toString()}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#d9534f']}
            tintColor="#d9534f"
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Tidak ada data gempa saat ini.</Text>
          </View>
        }
      />

      <Modal visible={showConfigModal} animationType="fade" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Pengaturan Sumber Data</Text>

            <Text style={styles.modalSubtitle}>Pilih Sumber Data:</Text>
            <View style={styles.sourceSwitchRow}>
              <TouchableOpacity
                style={[styles.switchBtn, dataSource === 'backend' && styles.switchBtnActive]}
                onPress={() => { setShowConfigModal(false); setLoading(true); fetchData('backend', ipAddress, port); }}
              >
                <Text style={[styles.switchText, dataSource === 'backend' && styles.switchTextActive]}>
                  Backend Lokal
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.switchBtn, dataSource === 'bmkg' && styles.switchBtnActive]}
                onPress={() => { setShowConfigModal(false); setLoading(true); fetchData('bmkg'); }}
              >
                <Text style={[styles.switchText, dataSource === 'bmkg' && styles.switchTextActive]}>
                  BMKG Live
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.switchBtn, dataSource === 'demo' && styles.switchBtnActive]}
                onPress={() => { setShowConfigModal(false); fetchData('demo'); }}
              >
                <Text style={[styles.switchText, dataSource === 'demo' && styles.switchTextActive]}>
                  Demo
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.modalSubtitle, { marginTop: 16 }]}>
              IP Laptop Backend (Port: 3000):
            </Text>
            <TextInput
              style={styles.textInput}
              value={tempIp}
              onChangeText={setTempIp}
              placeholder="192.168.1.5"
              autoCapitalize="none"
            />

            <View style={styles.modalPresetRow}>
              <TouchableOpacity onPress={() => setTempIp('192.168.1.5')} style={styles.presetBadge}>
                <Text style={styles.presetText}>192.168.1.5 (Wi-Fi)</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setTempIp('10.0.2.2')} style={styles.presetBadge}>
                <Text style={styles.presetText}>10.0.2.2 (Emulator)</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalButtonRow}>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#ccc' }]}
                onPress={() => setShowConfigModal(false)}
              >
                <Text style={styles.modalButtonText}>Tutup</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#d9534f' }]}
                onPress={handleSaveIp}
              >
                <Text style={[styles.modalButtonText, { color: '#fff' }]}>Terapkan</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f6f9',
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 0) + 10 : 10,
  },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 8,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1a1a1a',
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#777',
    marginTop: 2,
  },
  sourceBadge: {
    backgroundColor: '#e9ecef',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 20,
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#ced4da',
  },
  sourceBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#495057',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 24,
    paddingTop: 8,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    backgroundColor: '#f4f6f9',
  },
  loadingText: {
    marginTop: 14,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  loadingSubtext: {
    marginTop: 4,
    fontSize: 12,
    color: '#888',
  },
  errorIcon: {
    fontSize: 48,
    marginBottom: 8,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#d9534f',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 13,
    color: '#555',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 18,
  },
  actionButtonContainer: {
    width: '100%',
    gap: 10,
  },
  primaryButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 2,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  magBadge: {
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 6,
    alignItems: 'center',
    minWidth: 80,
  },
  magLabel: {
    color: '#ffffff',
    fontSize: 9,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  magValue: {
    color: '#ffffff',
    fontSize: 22,
    fontWeight: 'bold',
  },
  timeInfo: {
    alignItems: 'flex-end',
  },
  dateText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
  },
  timeText: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: '#f0f0f0',
    marginVertical: 12,
  },
  detailRow: {
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#777',
  },
  detailValue: {
    fontSize: 14,
    color: '#222',
    marginTop: 2,
  },
  potensiBox: {
    backgroundColor: '#fff8e6',
    borderColor: '#ffe58f',
    borderWidth: 1,
    padding: 10,
    borderRadius: 8,
    marginTop: 8,
  },
  potensiText: {
    fontSize: 12,
    color: '#8a6d3b',
    fontWeight: '500',
  },
  shakemapBox: {
    marginTop: 14,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  shakemapTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 8,
  },
  shakemapImage: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    backgroundColor: '#f8f9fa',
  },
  emptyContainer: {
    padding: 30,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: '#888',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 20,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 12,
    textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 13,
    color: '#555',
    marginBottom: 8,
  },
  sourceSwitchRow: {
    flexDirection: 'row',
    gap: 6,
    marginBottom: 10,
  },
  switchBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#ccc',
    alignItems: 'center',
  },
  switchBtnActive: {
    backgroundColor: '#d9534f',
    borderColor: '#d9534f',
  },
  switchText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#444',
  },
  switchTextActive: {
    color: '#fff',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
    backgroundColor: '#fafafa',
  },
  modalPresetRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
  },
  presetBadge: {
    backgroundColor: '#e9ecef',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  presetText: {
    fontSize: 11,
    color: '#495057',
  },
  modalButtonRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
    marginTop: 18,
  },
  modalButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  modalButtonText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#333',
  },
});