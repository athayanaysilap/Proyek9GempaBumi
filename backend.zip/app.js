import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 3000;

// Middleware CORS & JSON parser
app.use(cors());
app.use(express.json());

// Log setiap request yang masuk agar terlihat di terminal saat HP mencoba terhubung
app.use((req, res, next) => {
  const time = new Date().toLocaleTimeString();
  console.log(`[${time}] ${req.method} ${req.url} dari IP: ${req.ip || req.socket.remoteAddress}`);
  next();
});

// Data gempa statis cadangan (format resmi BMKG)
const mockGempaData = {
  Infogempa: {
    gempa: {
      Tanggal: "06 Nov 2026",
      Jam: "03:20:00 WIB",
      DateTime: "2026-11-05T20:20:00+00:00",
      Coordinates: "-1.14,120.15",
      Lintang: "1.14 LS",
      Bujur: "120.15 BT",
      Magnitude: "4.8",
      Kedalaman: "10 km",
      Wilayah: "Pusat gempa berada di darat 40 km timur laut Sigi",
      Potensi: "Gempa ini dirasakan untuk diteruskan pada masyarakat",
      Dirasakan: "III Sigi, II Palu",
      Shakemap: "20261104145634.mmi.jpg"
    }
  }
};

// Route tes status server
app.get('/', (req, res) => {
  res.json({
    status: 'success',
    message: 'Backend Express Info Gempa Aktif!',
    endpoints: ['/api/gempa']
  });
});

// Route utama data gempa
app.get('/api/gempa', async (req, res) => {
  try {
    // Ambil data live BMKG jika terkoneksi internet
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    const bmkgRes = await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json', {
      signal: controller.signal,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });
    clearTimeout(timeout);

    if (bmkgRes.ok) {
      const liveData = await bmkgRes.json();
      console.log('-> Berhasil mengambil data REALTIME dari BMKG.');
      return res.json(liveData);
    }
  } catch (err) {
    console.log('-> Gagal fetch BMKG online, menggunakan data mock lokal:', err.message);
  }

  // Gunakan data cadangan jika offline
  res.json(mockGempaData);
});

// PENTING: Wajib bind ke '0.0.0.0' agar menerima koneksi dari HP via Wi-Fi
app.listen(PORT, '0.0.0.0', () => {
  console.log('====================================================');
  console.log(`  SERVER BACKEND GEMPA BERJALAN DI PORT ${PORT}`);
  console.log(`  - Akses dari Laptop : http://localhost:${PORT}/api/gempa`);
  console.log(`  - Akses dari HP     : http://192.168.1.5:${PORT}/api/gempa`);
  console.log('====================================================');
  console.log('Menunggu request dari Expo Go di HP...\n');
});
